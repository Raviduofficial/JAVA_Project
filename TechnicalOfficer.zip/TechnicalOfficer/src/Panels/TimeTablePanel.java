package Panels;

import db.MyDbConnector;

import javax.swing.*;
import java.awt.*;

public class TimeTablePanel extends JPanel {
     public TimeTablePanel(){
            setBackground(Color.ORANGE);
     }
     private void initUi() {
         MyDbConnector dbConnector = new MyDbConnector();
         dbConnector.getMyConnection();

     }

}
