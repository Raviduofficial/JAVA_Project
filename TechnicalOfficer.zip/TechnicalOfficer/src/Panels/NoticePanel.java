package Panels;

import db.MyDbConnector;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class NoticePanel extends JPanel {

    private JTable table;
    private DefaultTableModel model;

    public NoticePanel(){
        setBackground(Color.GRAY);

        /*String column[] = {"notice_id","notice_title","notice_content","notice_date"};
        model = new DefaultTableModel(column,0);
        table = new JTable(model);

        setLayout(new BorderLayout());
        add(, BorderLayout.CENTER);

        JScrollPane sp = new JScrollPane(table);

        frame.add(sp);
        frame.setSize(300,400);
        frame.setVisible(true);*/

    }
    private void initUI(){

        MyDbConnector dbConnector = new MyDbConnector();
        dbConnector.getMyConnection();
    }
}
