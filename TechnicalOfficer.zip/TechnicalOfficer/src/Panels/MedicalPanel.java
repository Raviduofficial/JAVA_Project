package Panels;

import javax.swing.*;
import java.awt.*;

public class MedicalPanel extends JPanel {

    private String userId;
    public MedicalPanel(String userId){
        this.userId = userId;
        setBackground(Color.BLACK);
    }
}
