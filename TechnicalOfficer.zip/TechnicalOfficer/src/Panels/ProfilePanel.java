package Panels;

import javax.swing.*;
import java.awt.*;

public class ProfilePanel extends JPanel {

    private String userId;

    public ProfilePanel(String userId){
        this.userId=userId;
        setBackground(Color.GREEN);


    }
}
