package Panels;

import javax.swing.*;
import java.awt.*;

public class AttendancePanel extends JPanel {

    private JLabel courseLabel,sessionTypeLabel,udIdLabel,absentPresentLabel,setDateLabel;
    //private JComboBox courseNameBox,s_typeBox,ugIdBox,ap_Box;
    private JButton addButton,showButton;


    JComboBox comboBox;

    String userId;
    public AttendancePanel(String userId){
            setBackground(Color.BLUE);
            initUi();

    }
    public void initUi(){
            setLayout(null);
            String[] courseId = {"11223","2324734","28324637"};
            comboBox = new JComboBox(courseId);
            comboBox.setBounds(0,0,100,50);

            add(comboBox);


    }

}
