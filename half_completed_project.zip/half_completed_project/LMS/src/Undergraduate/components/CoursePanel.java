package Undergraduate.components;

import Undergraduate.db.MyDbConnector;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URI;
import java.sql.*;

public class CoursePanel extends JPanel {
    private JTable courseTable;
    private DefaultTableModel tableModel;

    public CoursePanel() {
        setLayout(new BorderLayout());
       

        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(Color.BLACK);
        titlePanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JLabel titleLabel = new JLabel("Course Overview");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setForeground(Color.WHITE);

        titlePanel.add(titleLabel, BorderLayout.WEST);
        add(titlePanel, BorderLayout.NORTH);

        String[] columns = {"Course ID", "Course Name", "Lecturer ID", "Credit", "Type", "Content Link"};
        tableModel = new DefaultTableModel(columns, 0);
        courseTable = new JTable(tableModel) {
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };


        JTableHeader header = courseTable.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setBackground(new Color(102, 153, 255));
        header.setForeground(Color.WHITE);
        header.setReorderingAllowed(false);


        courseTable.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        courseTable.setRowHeight(30);

        courseTable.setDefaultEditor(Object.class, null);
        courseTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                JLabel cell = (JLabel) super.getTableCellRendererComponent(
                        table, value, isSelected, hasFocus, row, column);

                if (column == 5 && value != null && value.toString().startsWith("http")) {
                    cell.setForeground(new Color(0, 102, 204)); // Link blue
                    cell.setText("<html><u>" + value.toString() + "</u></html>");
                } else {
                    cell.setForeground(Color.BLACK);
                }

                if (isSelected) {
                    cell.setBackground(new Color(173, 216, 230)); // Light blue
                } else {
                    cell.setBackground(Color.WHITE);
                }

                return cell;
            }
        });

        
        courseTable.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = courseTable.rowAtPoint(e.getPoint());
                int column = courseTable.columnAtPoint(e.getPoint());
                if (column == 5) {
                    String url = courseTable.getValueAt(row, column).toString();
                    try {
                        Desktop.getDesktop().browse(new URI(url));
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(CoursePanel.this, "Failed to open link.");
                    }
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(courseTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        add(scrollPane, BorderLayout.CENTER);

        loadCourseData();
    }

    private void loadCourseData() {
        MyDbConnector mdc = new MyDbConnector();
        try (Connection con = mdc.getMyConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM course")) {

            while (rs.next()) {
                String id = rs.getString("course_id");
                String name = rs.getString("course_name");
                String lecId = rs.getString("lec_id");
                int credit = rs.getInt("credit");
                String type = rs.getString("course_type");
                String link = rs.getString("course_content");

                tableModel.addRow(new Object[]{id, name, lecId, credit, type, link});
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading course data: " + e.getMessage());
        }
    }
}
