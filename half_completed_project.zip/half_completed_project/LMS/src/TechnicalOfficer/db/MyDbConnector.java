package TechnicalOfficer.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class MyDbConnector  {


    public Connection getMyConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/javaminiproject", "root", "Dewage@22");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
