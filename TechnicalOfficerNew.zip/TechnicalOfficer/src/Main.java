import Panels.NoticePanel;

public class Main {
    public static void main(String[] args) {
        new TechnicalOfficer("to0002");
        new NoticePanel();
    }
}
